rm soundtouch-linux.tar.gz
cd ..
tar -czf soundtouch-linux.tar.gz soundtouch-linux
mv soundtouch-linux.tar.gz soundtouch-linux
cd soundtouch-linux
