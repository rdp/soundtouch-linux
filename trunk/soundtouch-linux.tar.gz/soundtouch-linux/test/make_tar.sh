tar -czf soundtouch-linux.tar.gz .
