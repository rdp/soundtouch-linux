g++ source/example/SoundStretch/*.cpp source/SoundTouch/*.cpp source/example/bpm/*.cpp -I include -fcheck-new -o soundstretch
sudo cp soundstretch /usr/bin
